# Pipepair

**Crash-repair pipeline runner** for any device — run YAML pipelines with fallback and retry.

## Usage

```bash
pipepair