# fallback1.py
print("Fallback: Step 1 failed, running fallback script.")
# Simulate fallback action