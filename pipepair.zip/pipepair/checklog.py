def check_pipepair_log(log_path='pipepair.log'):
    error_found = False
    with open(log_path, 'r') as log_file:
        for line in log_file:
            if 'failed' in line.lower() or 'error' in line.lower():
                print(f"Error found: {line.strip()}")
                error_found = True
    if not error_found:
        print("No errors found in pipepair.log")
    else:
        print("Errors were found. Check above lines.")

if __name__ == "__main__":
    check_pipepair_log()