from .core import run_pipeline

def main():
    run_pipeline()